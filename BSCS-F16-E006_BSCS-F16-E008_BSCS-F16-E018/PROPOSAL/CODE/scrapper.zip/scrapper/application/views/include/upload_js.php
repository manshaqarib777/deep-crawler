<link href="<?php echo base_url();?>plugins/upload/uploadfile.css" rel="stylesheet">
<script src="<?php echo base_url();?>plugins/upload/jquery.uploadfile.min.js"></script>
<style>
	.ajax-file-upload-error{color:red;}
</style>