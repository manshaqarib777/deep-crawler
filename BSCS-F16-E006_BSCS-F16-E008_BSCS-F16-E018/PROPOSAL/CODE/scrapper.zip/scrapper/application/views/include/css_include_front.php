<!-- core CSS -->
<link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
 <link href="<?php echo base_url();?>bootstrap/css/datepicker.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/animate.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/main.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/custom.css" rel="stylesheet">
<!--[if lt IE 9]>
<script src="<?php echo base_url();?>assets/js/html5shiv.js"></script>
<script src="<?php echo base_url();?>assets/js/respond.min.js"></script>
<![endif]-->     
 
