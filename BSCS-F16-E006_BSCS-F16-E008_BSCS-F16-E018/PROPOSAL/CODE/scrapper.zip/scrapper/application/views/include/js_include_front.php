<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.js"></script>
<!-- end of for modal effect -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>bootstrap/js/bootstrap-datepicker.js"></script>

